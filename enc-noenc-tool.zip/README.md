
# ENC ⇄ NO ENC Tool

Alat ringkas untuk encode dan decode Base64 dalam JavaScript. Sesuai digunakan untuk encode skrip sebelum sebaran.

## Cara Guna
1. Masukkan kod asal ke ruang atas.
2. Klik `ENCODE` untuk dapatkan kod yang telah diubah.
3. Klik `DECODE` untuk buka semula kod yang telah di-encode.
